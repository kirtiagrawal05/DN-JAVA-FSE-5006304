
public class CustomerService {
	private final CustomerRepository customerRepository;

    // Constructor Injection
    public CustomerService(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
    }

    public String findCustomer(String customerId) {
        return customerRepository.findCustomerById(customerId);
    }
}
