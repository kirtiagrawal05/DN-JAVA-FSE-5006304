
public class LoggerTest {
	public static void main(String[] args) throws InterruptedException {
        testSingletonInstance();
        testMultiThreadedAccess();
    }

    public static void testSingletonInstance() {
        Logger logger1 = Logger.getInstance();
        Logger logger2 = Logger.getInstance();
        Logger logger3 = Logger.getInstance();
        
        if (logger1 == logger2 && logger2 == logger3) {
            System.out.println("Test 1: Singleton instance test passed");
        } else {
            System.out.println("Test 1: Singleton instance test failed");
        }
    }

    public static void testMultiThreadedAccess() throws InterruptedException {
        Logger logger1 = Logger.getInstance();

        Thread thread1 = new LoggerAccessThread();
        Thread thread2 = new LoggerAccessThread();
        Thread thread3 = new LoggerAccessThread();

        thread1.start();
        thread2.start();
        thread3.start();
        
        thread1.join();
        thread2.join();
        thread3.join();

        if (logger1 == LoggerAccessThread.logger2 && logger1 == LoggerAccessThread.logger3) {
            System.out.println("Test 2: Multi-threaded access test passed");
        } else {
            System.out.println("Test 2: Multi-threaded access test failed");
        }
    }

    private static class LoggerAccessThread extends Thread {
        public static Logger logger2;
        public static Logger logger3;

        @Override
        public void run() {
            logger2 = Logger.getInstance();
            logger3 = Logger.getInstance();
        }
    }

}
