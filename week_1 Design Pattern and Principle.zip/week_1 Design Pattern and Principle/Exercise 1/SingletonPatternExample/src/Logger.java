
public class Logger {

	private static Logger instance;

	private Logger() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public static Logger getInstance() {
        if (instance == null) {
            synchronized (Logger.class) {
                if (instance == null) {
                    instance = new Logger();
                }
            }
        }
        return instance;
    }
	@Override
    protected Object clone() throws CloneNotSupportedException {
        throw new CloneNotSupportedException("Cannot clone a singleton");
    }

    // Prevent deserialization
    private Object readResolve() {
        return instance;
    }
}
