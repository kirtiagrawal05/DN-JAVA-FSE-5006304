
public class DocumentFactoryTest {

	public static void main(String[] args) {
		DocumentFactory wordFact = new WordFactory();
        Document wordDoc = wordFact.createDocument();
        wordDoc.open();
        wordDoc.save();
        wordDoc.close();

        DocumentFactory pdfFact = new PDFFactory();
        Document pdfDoc = pdfFact.createDocument();
        pdfDoc.open();
        pdfDoc.save();
        pdfDoc.close();

        DocumentFactory excelFact = new ExcelFactory();
        Document excelDoc = excelFact.createDocument();
        excelDoc.open();
        excelDoc.save();
        excelDoc.close();
	}

}
