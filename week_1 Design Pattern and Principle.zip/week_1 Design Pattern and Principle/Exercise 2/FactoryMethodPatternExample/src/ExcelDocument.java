
public interface ExcelDocument {
	void open();
    void save();
    void close();

}
