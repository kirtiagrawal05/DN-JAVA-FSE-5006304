
public interface WordDocument {
	void open();
    void save();
    void close();
}
