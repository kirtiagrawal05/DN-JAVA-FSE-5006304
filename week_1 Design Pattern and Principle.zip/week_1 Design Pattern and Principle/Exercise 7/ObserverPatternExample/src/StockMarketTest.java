
public class StockMarketTest {
	public static void main(String[] args) {
        StockMarket stockMarket = new StockMarket();

        Observer mobileApp = new MobileApp("App1");
        Observer webApp = new WebApp("WebApp1");

        stockMarket.register(mobileApp);
        stockMarket.register(webApp);

        stockMarket.setStockData("AAPL: 150.00 USD");
        System.out.println("");


        stockMarket.deregister(webApp);

        stockMarket.setStockData("MSFT: 300.00 USD");
    }

}
