
public class ProxyImageTest {
	public static void main(String[] args) {
        Image image1 = new ProxyImage("test1.jpg");

        // The image will be loaded from disk
        image1.display();
        System.out.println("");

        // The image will not be loaded from disk, as it is already cached
        image1.display();
        System.out.println("");

    }

}
