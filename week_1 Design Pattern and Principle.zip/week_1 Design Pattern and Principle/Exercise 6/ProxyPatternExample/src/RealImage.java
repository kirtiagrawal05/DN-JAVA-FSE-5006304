
public class RealImage implements Image{
	private String filename;

    public RealImage(String filename) {
        this.filename = filename;
        loadImageFromDisk();
    }

    private void loadImageFromDisk() {
        System.out.println("Loading image from " + filename);
        // Simulate loading image from a remote server
        try {
            Thread.sleep(2000); // Simulate time delay for loading the image
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("Image loaded from " + filename);
    }

    public void display() {
        System.out.println("Displaying " + filename);
    }

}
