
public class StudentTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 // Fetch the student record
        Student model = retrieveStudentFromDatabase();

        // Create a view to show student details on the console
        StudentView view = new StudentView();

        // Create a controller
        StudentController controller = new StudentController(model, view);

        // Update the view
        controller.updateView();

        // Update model data
        controller.setStudentName("John Doe");

        // Update the view again to reflect changes
        System.out.println("\nAfter updating student details:");
        controller.updateView();
    }

    private static Student retrieveStudentFromDatabase() {
        Student student = new Student();
        student.setId("S01");
        student.setName("Jane Smith");
        student.setGrade("A");
        return student;
    
	}

}
