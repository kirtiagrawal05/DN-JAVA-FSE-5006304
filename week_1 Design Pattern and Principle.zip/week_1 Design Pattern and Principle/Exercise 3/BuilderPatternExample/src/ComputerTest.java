
public class ComputerTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Computer Computer = new Computer.Builder()
	            .setCpu("Intel i9")
	            .setRam(32)
	            .setStorage(1024)
	            .build();
	        System.out.println("Gaming Computer: " + Computer);


	}

}
