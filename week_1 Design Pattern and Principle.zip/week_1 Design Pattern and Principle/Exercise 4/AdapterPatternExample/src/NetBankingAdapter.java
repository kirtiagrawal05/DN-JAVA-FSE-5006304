
public class NetBankingAdapter implements PaymentProcessor {
	private NetBanking NetBankingGateway;

    public NetBankingAdapter() {
        this.NetBankingGateway = new NetBanking();
    }
    
    public void processPayment(double amount) {
    	NetBankingGateway.sendPayment(amount);
    }

}
