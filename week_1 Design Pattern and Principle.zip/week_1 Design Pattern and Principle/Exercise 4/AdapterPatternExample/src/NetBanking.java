
public class NetBanking {
	public void sendPayment(double amount) {
        System.out.println("Processing payment of Rs. " + amount + " through Net Banking.");
    }

}
