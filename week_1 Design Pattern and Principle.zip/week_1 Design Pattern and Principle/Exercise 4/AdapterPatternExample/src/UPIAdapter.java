
public class UPIAdapter implements PaymentProcessor {
	private UPI UPIGateway;

    public UPIAdapter() {
        this.UPIGateway = new UPI();
    }
    
    public void processPayment(double amount) {
        UPIGateway.sendPayment(amount);
    }

}
