
public class PaymentTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PaymentProcessor UPIProcessor = new UPIAdapter();
		PaymentProcessor NetBankingProcessor = new NetBankingAdapter();

		UPIProcessor.processPayment(1000.00);
		NetBankingProcessor.processPayment(20000.00);
	}

}
