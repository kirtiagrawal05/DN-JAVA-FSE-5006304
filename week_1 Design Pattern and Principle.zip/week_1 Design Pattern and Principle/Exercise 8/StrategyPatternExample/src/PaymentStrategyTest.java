
public class PaymentStrategyTest {
	public static void main(String[] args) {
        PaymentContext paymentContext = new PaymentContext();

        PaymentStrategy creditCardPayment = new CreditCardPayment("1234-5678-9012-3456");
        PaymentStrategy payPalPayment = new PayPalPayment("Kirti@gmail.com");

        paymentContext.setPaymentStrategy(creditCardPayment);
        paymentContext.executePayment(10000.0);

        paymentContext.setPaymentStrategy(payPalPayment);
        paymentContext.executePayment(2000.0);
    }

}
