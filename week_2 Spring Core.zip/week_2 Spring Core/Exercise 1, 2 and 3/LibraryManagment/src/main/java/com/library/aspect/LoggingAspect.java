package com.library.aspect;

import org.springframework.context.annotation.EnableAspectJAutoProxy;

@EnableAspectJAutoProxy
public class LoggingAspect {
	@Before("execution(* com.library.service.*.*(..))")
    public void logBeforeMethod() {
        System.out.println("Method execution started.");
    }
}
