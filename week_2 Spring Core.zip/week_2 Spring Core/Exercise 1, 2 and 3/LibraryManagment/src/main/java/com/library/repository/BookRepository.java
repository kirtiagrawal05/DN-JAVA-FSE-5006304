package com.library.repository;

public class BookRepository {
	public void displayBooks() {
		// TODO Auto-generated method stub
		System.out.println("This is BookRepository class");
		
	}

}
