package exercise.Library_Managment;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
     // Load Spring context
        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");

        // Retrieve beans for constructor injection
        BookService bookServiceConstructor = (BookService) context.getBean("bookServiceConstructor");

        // Retrieve beans for setter injection
        BookService bookServiceSetter = (BookService) context.getBean("bookServiceSetter");

        // Retrieve the BookRepository bean
        BookRepository bookRepository = (BookRepository) context.getBean("bookRepository");

        // Test the configuration
        System.out.println("BookService (Constructor Injection): " + bookServiceConstructor);
        System.out.println("BookService (Setter Injection): " + bookServiceSetter);
        System.out.println("BookRepository: " + bookRepository);
    }
}
