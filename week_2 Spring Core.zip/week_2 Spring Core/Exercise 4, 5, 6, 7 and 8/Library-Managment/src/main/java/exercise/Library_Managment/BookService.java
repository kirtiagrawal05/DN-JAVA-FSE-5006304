package exercise.Library_Managment;

import org.springframework.stereotype.Service;

@Service
public class BookService {
	 private BookRepository bookRepository;

	    // Constructor for constructor injection
	    public BookService(BookRepository bookRepository) {
	        this.bookRepository = bookRepository;
	    }

	    // Default constructor for setter injection
	    public BookService() {}

	    // Setter for BookRepository
	    public void setBookRepository(BookRepository bookRepository) {
	        this.bookRepository = bookRepository;
	    }
}
