package exercise.Library_Managment;

import org.springframework.stereotype.Repository;

@Repository
public class BookRepository {

}
