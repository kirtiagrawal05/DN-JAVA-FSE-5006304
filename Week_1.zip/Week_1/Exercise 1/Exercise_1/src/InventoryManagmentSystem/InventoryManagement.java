package InventoryManagmentSystem;
import java.util.ArrayList;
public class InventoryManagement {
    private ArrayList<Product> productList;

    public InventoryManagement() {
        productList = new ArrayList<>();
    }

    public void addProduct(Product product) {
        productList.add(product);
    }

    public void updateProduct(String productId, String productName, int quantity, double price) {
        for (Product product : productList) {
            if (product.getProductId().equals(productId)) {
                product.setProductName(productName);
                product.setQuantity(quantity);
                product.setPrice(price);
                break;
            }
        }
    }

    public void deleteProduct(String productId) {
        productList.removeIf(product -> product.getProductId().equals(productId));
    }

    public void displayProducts() {
        for (Product product : productList) {
            System.out.println(product);
        }
    }

    public static void main(String[] args) {
        InventoryManagement inventory = new InventoryManagement();

        // Adding products
        inventory.addProduct(new Product("P001", "Product 1", 10, 100.0));
        inventory.addProduct(new Product("P002", "Product 2", 20, 200.0));
        
        // Displaying products
        System.out.println("Products in Inventory:");
        inventory.displayProducts();

        // Updating a product
        inventory.updateProduct("P001", "Updated Product 1", 15, 150.0);

        // Displaying products after update
        System.out.println("\nProducts after Update:");
        inventory.displayProducts();

        // Deleting a product
        inventory.deleteProduct("P002");

        // Displaying products after deletion
        System.out.println("\nProducts after Deletion:");
        inventory.displayProducts();
    }
}
