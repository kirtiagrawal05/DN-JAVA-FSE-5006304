
public class TaskLinkedList {
    private Node head;

    public TaskLinkedList() {
        head = null;
    }

    // Add a new task to the end of the list
    public void addTask(Task task) {
        Node newNode = new Node(task);
        if (head == null) {
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
    }

    // Search for a task by taskId
    public Task searchTaskById(int taskId) {
        Node current = head;
        while (current != null) {
            if (current.task.getTaskId() == taskId) {
                return current.task;
            }
            current = current.next;
        }
        return null;
    }

    // Traverse and print all tasks in the list
    public void traverseTasks() {
        Node current = head;
        while (current != null) {
            System.out.println(current.task);
            current = current.next;
        }
    }

    // Delete a task by taskId
    public boolean deleteTaskById(int taskId) {
        if (head == null) {
            return false;
        }
        if (head.task.getTaskId() == taskId) {
            head = head.next;
            return true;
        }
        Node current = head;
        while (current.next != null && current.next.task.getTaskId() != taskId) {
            current = current.next;
        }
        if (current.next == null) {
            return false;
        }
        current.next = current.next.next;
        return true;
    }

    public static void main(String[] args) {
        TaskLinkedList taskList = new TaskLinkedList();

        Task t1 = new Task(1, "Task 1", "Pending");
        Task t2 = new Task(2, "Task 2", "In Progress");
        Task t3 = new Task(3, "Task 3", "Completed");

        taskList.addTask(t1);
        taskList.addTask(t2);
        taskList.addTask(t3);

        System.out.println("Task List:");
        taskList.traverseTasks();

        System.out.println("\nSearching for Task with ID 2:");
        Task searchResult = taskList.searchTaskById(2);
        System.out.println(searchResult != null ? searchResult : "Task not found");

        System.out.println("\nDeleting Task with ID 2:");
        boolean isDeleted = taskList.deleteTaskById(2);
        System.out.println(isDeleted ? "Task deleted successfully" : "Task not found");

        System.out.println("\nTask List after Deletion:");
        taskList.traverseTasks();
    }
}

