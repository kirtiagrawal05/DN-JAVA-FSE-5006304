
import java.util.*;

public class EmployeeManagement {
    private Employee[] employees;
    private int count;

    public EmployeeManagement(int capacity) {
        employees = new Employee[capacity];
        count = 0;
    }

    public void addEmployee(Employee employee) {
        if (count == employees.length) {
            employees = Arrays.copyOf(employees, employees.length * 2);
        }
        employees[count++] = employee;
    }

    public Employee searchEmployeeById(int employeeId) {
        for (int i = 0; i < count; i++) {
            if (employees[i].getEmployeeId() == employeeId) {
                return employees[i];
            }
        }
        return null;
    }

    public void traverseEmployees() {
        for (int i = 0; i < count; i++) {
            System.out.println(employees[i]);
        }
    }

    public boolean deleteEmployeeById(int employeeId) {
        for (int i = 0; i < count; i++) {
            if (employees[i].getEmployeeId() == employeeId) {
                employees[i] = employees[--count];
                employees[count] = null;
                return true;
            }
        }
        return false;
    }

    public static void main(String[] args) {
        EmployeeManagement management = new EmployeeManagement(2);

        Employee e1 = new Employee(1, "Alice", "Developer", 70000);
        Employee e2 = new Employee(2, "Bob", "Manager", 85000);
        Employee e3 = new Employee(3, "Charlie", "Designer", 60000);

        management.addEmployee(e1);
        management.addEmployee(e2);
        management.addEmployee(e3);

        System.out.println("Employees List:");
        management.traverseEmployees();

        System.out.println("\nSearching for Employee with ID 2:");
        Employee searchResult = management.searchEmployeeById(2);
        System.out.println(searchResult != null ? searchResult : "Employee not found");

        System.out.println("\nDeleting Employee with ID 2:");
        boolean isDeleted = management.deleteEmployeeById(2);
        System.out.println(isDeleted ? "Employee deleted successfully" : "Employee not found");

        System.out.println("\nEmployees List after Deletion:");
        management.traverseEmployees();
    }
}

