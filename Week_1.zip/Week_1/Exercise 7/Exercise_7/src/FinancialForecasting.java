
public class FinancialForecasting {
	public static double calculateFutureValue(double currentValue, double growthRate, int periods) {
        // Base case: no more periods left to forecast
        if (periods == 0) {
            return currentValue;
        }
        // Recursive case: calculate the future value for one less period
        return calculateFutureValue(currentValue * (1 + growthRate), growthRate, periods - 1);
    }

    public static void main(String[] args) {
        double pastValue = 1000.0; // Example past value
        double growthRate = 0.05;  // Example growth rate of 5%
        int periods = 10;          // Forecasting 10 periods into the future

        double futureValue = calculateFutureValue(pastValue, growthRate, periods);
        System.out.printf("The future value after %d periods is: %.2f%n", periods, futureValue);
    }
}
